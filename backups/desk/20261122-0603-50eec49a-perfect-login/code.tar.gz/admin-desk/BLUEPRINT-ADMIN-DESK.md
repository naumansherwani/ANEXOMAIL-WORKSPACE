> [22 Nov 2026 05:35 PKT] HIS ORDER (05:11): PHASE NAMES FOLLOW THE ALPHABET, A THEN B, NOT S. R4-1b steps renamed: S0=A (browser HTTP/3 proof), S1=B (bridge.rs signed doors), S2=C (WebTransport server + kernel stream client), S3=D (Command Bar UI), S4=E (team fan-out), S5=F (MoQ). Old S-names in older lines mean these letters. NOW = B written, AND the Desk login scrollbar fix comes BEFORE B is called green (his word).
> [22 Nov 2026 05:35 PKT] LOGIN SCROLLBAR FIXED (cause found in sandbox, 390x844 and 1280x720 had page height 886/798 > screen because DeskScene padding 88px top + 72px bottom): DeskScene got a `pad` prop, DeskSignIn passes clamp(12px,6dvh,88px) 16px clamp(12px,4dvh,72px). Now fits, no page scrollbar, at 390x844, 820x1180, 1280x720, 1366x768, 1440x900, 1920x1080; only screens shorter than the card (360x640, 390x667, 1024x600) still scroll because the card itself is taller. Needs his desk-install + my live look.

> [22 Nov 2026 05:12 PKT PKT] R4-1b S1 WRITTEN (not green): bridge.rs, 4 signed doors (summary, services, alerts, alerts/act), DB-side access via fadm_need, 27 cargo tests ok. Needs his desk-install + my Chrome look. Tech: Rust + Tokio + Axum, Rule 52 signed, PostgreSQL RLS. HTTP fallback banned: doors feed the S2 WebTransport stream.

> [22 Nov 2026 04:59 PKT PKT] S0 EVIDENCE 4 (his pcap): Chrome QUIC packets from 182.185.188.151 REACH UDP 4400 and the Desk completes the QUIC handshake. Network and Hetzner firewall CLEARED. WebTransport CONNECT fails only because the Desk has no WebTransport yet (S2). Open: Chrome navigation still h2 (alt-svc use). NOT green.

> [22 Nov 2026 04:46 PKT] HIS LAW (04:44): HTTP FALLBACK IS BANNED for the Admin Desk and stays banned until HE gives approval. NO signed poll doors, NO SSE, NO h1/h2 data path. HTTP/3 ONLY (WebTransport primary, MoQ later); everything else intact. This overrides D2 and S1 in BRIDGE-TRANSPORT-DECISION-22NOV.md. S1 is now the Rust Bridge data layer (bridge.rs) read through the same HTTP/3 + WebTransport path, Rule 52 signed. S0 evidence 3: public Alt-Svc header IS sent (h3=":4400"; ma=86400), but tcpdump 20 s on UDP 4400 (non-loopback) saw ZERO packets; my earlier '376 ms = reachable' is WEAK (a local Chrome rejection looks the same). S0 NOT green.


> [22 Nov 2026 04:32 PKT PKT] S0: QUIC to UDP 4400 WORKS from his Chrome (WebTransport handshake answered in 376 ms, fails only at CONNECT = S2 work). Chrome stays h2 because an open HTTP/2 session is reused (APNIC): retest on a NEW connection. CSP connect-src needs :4400 for S2. His server repo was stale: ad-auto again applies AD3 4 s patch.

> [22 Nov 2026 04:25 PKT PKT, his 04:24] HIS FAITH: WebTransport PRIMARY always, fallback kept, EVERYTHING TODAY (not 4 days), one phase green in Chrome then next, his full technology list on every phase. STEP 0 NOT PROVEN: server h3check OK (loopback + public) but real Chrome shows h2 for admindesk (h3 for the founder site). Diagnosing. AD3 4 s patch still not applied on his DB (ad-auto skipped twice).

> [22 Nov 2026 04:15 PKT PKT, his 04:15] DECISION: Bridge live transport = WEBTRANSPORT (QUIC) on the Desk UDP 4400 (443 is founder), signed poll doors = fallback, Rule 52 per stream message (live since R3d for doors), MoQ tracks named now, framing after (not in the 4 days). Prerequisite: real HTTP/3 proof (desk-h3-check). Full: docs/claude/admin-desk/BRIDGE-TRANSPORT-DECISION-22NOV.md

> [22 Nov 2026 04:07 PKT PKT, his 04:07] HIS SERVER: desk-install OK (new binary with probes running, db login live). ad-auto SKIPPED AD3 because the CHECK was all true: my 4 s probe patch was NOT applied. FIXED: AD3-check has a new row (probes every 4 s) that is false until the patch runs, so his next ad-auto runs AD3 again (sandbox proved: before f, after 18 rows t). His answers: founder rows stay in Founder Bridge, I decide what an employee needs; Desk Bridge = for the Anexomail company needs only. NEXT: R4-1b step 3 signed doors.

> [22 Nov 2026 03:59 PKT PKT] R4-1b STEP 2 WRITTEN (not on his server): server/src/probes.rs (db, signer, h3_edge, tls every 4 s; ledger, clamav every 60 s; 24 cargo tests ok) + AD3.sql patch (probe floor 1 s, 4 s rows; stale = 12 s). mail_in/mail_out/dns/storage_box have NO probe yet = UNKNOWN on purpose. ClamAV probe needs DESK_CLAMD_SOCK.

> [22 Nov 2026 03:58 PKT PKT, his 03:57] BRIDGE: inbox placement DROPPED, Merkle anchor DROPPED, stale rule = probes 4 s / stale 12 s, honest insider radar, freeze shows measured time. My advice on 2 decisions recorded in BRIDGE-FEATURES-22NOV.md. NOW: R4-1b step 2 Rust probes.

> [22 Nov 2026 03:53 PKT PKT, his 03:52] AD3 LIVE on his server (17 rows t). BRIDGE SECOND LIST: docs/claude/admin-desk/BRIDGE-FEATURES-22NOV.md (11 features with side DESK/FOUNDER, tech, step, honest notes; Desk isolation kept; founder rows need his haan). NEXT: R4-1b step 2 Rust probes (4 s heartbeat, stale at 12 s).

> [22 Nov 2026 03:43 PKT PKT, his 03:38] BRIDGE R4-1b: PLAN docs/claude/admin-desk/BRIDGE-PLAN-22NOV.md; AD3.sql (Bridge: alert center, service health, incidents, watches, command-bar summary) WRITTEN + sandbox-tested (selftest + 17 check rows t, idempotent); NOT yet on his server (ad-auto). Cases/queues/SLA SQL = AD4. Max price FINAL 125,000 (his word 03:38).
> ## >>> ADMIN DESK RULES (his 22 Nov 2026 01:36 PKT, STANDING): (1) every phase and subphase is written WITH its advance technology next to it; (2) the Desk is a REAL business system (his business runs from here now and in future): real accounts, real data, no mock, no demo data, every change wired end to end and live-proven; (3) every phase ships with its REAL pull command the same night (as many phases as possible each night); (4) PRESERVE the Desk code as a product: the SAME Admin Desk will be built for NEXATECT, AXONETIS and ANEXVOT PAY (each its own isolated deployment, host, key, DB role; never mixed); (5) Rule 52 on every call. <<<
> [03:19 PKT, his 03:18] DASHBOARD PLAN: DASHBOARD-LIVE-COMMAND-22NOV.md = Live Command Bar (A1 Live SLA Clock, A2 Active P1 alerts with package prices, A3 Mail and QUIC pipeline heartbeat) + B1-B13 world-advance cards (Google/Microsoft/Zoho/Proton) + C1-C10 Desk-only features, each with its phase and advance technology; every number real or 'not measured'. PRICE: awam blueprint says Business Max 125,000 pounds; his 21,500 NOT found, awaiting his word. Order unchanged.
> [03:08 PKT, his 03:08] 4-DAY TARGET: FOUR-DAY-PLAN-22NOV.md (Day1 Bridge + AD3 SQL + AD2 Rust door; Day2 inboxes + cases + routing; Day3 auto mail + SLA + Managed Move-In; Day4 People + deliverability + security screens + CRM base + final Chrome proof). WORLD research modules (WORLD-ADMIN-DESK-FEATURES-22NOV.md, 24 registry folders) = the module list of those phases. His answers: alerts to Desk's own bridge; Chairman Escalations inside the Desk (owner-only); 'Enterprise 20,500' was the Business Max price, Enterprise is AFTER Admin Desk. Order NOT broken.
> [22 Nov 2026 03:02 PKT, his 03:01] SIDEBAR PLAN + 6 LOOPHOLES saved verbatim: SIDEBAR-SECTIONS-AND-LOOPHOLES-22NOV.md (4 rail groups: Command & Live Pulse / Support & Operations / Organization & Governance / Verification & Escalation; new items Live Pulse & SLA, Domains & DNS Health, Customers & Plans, Security & Policies, Chairman Escalations). 7 lines conflict with his own laws (support@ banned, Founder Bridge/Vault isolation, Enterprise price, Merkle, DBSC) = listed there for his haan. Rail rename = step R4-1c after his haan. Phase order unchanged.
> [22 Nov 2026 02:45 PKT, his 02:43] AD2 SQL LIVE on his server (20 CHECK rows t). R4-1a UI LIVE (his phone screenshot: rail + original logo). THIS STEP: pin/unpin, scrollbar, groups ANEXOMAIL WORKSPACE / ADMIN DESK (user problems) / Company; 'Admin Desk' text under the logo removed. NEXT R4-1b (top bar Live+Trusted, profile menu, Desk Bridge, real cards) then R4-2 inboxes, AD2 Rust door, R4-11 Managed Move-In MOVE, R5a People MOVE (only Finance + Polar stay in founder). Full audit + order: FOUNDER-TO-DESK-AUDIT-22NOV.md. Phase order above is NOT broken.
> [21 Nov 2026 23:10 PKT] WHERE WE STAND: login door + own DB login LIVE (his install 23:08). NEXT: his sign-in, then Rule 52 Desk kernel RPC, DBSC, orb, passkey, R4 copy, R3p (palette kept for Premium/Max). Full status: BLUEPRINT-STATUS-21NOV.md
> [21 Nov 2026 20:44 PKT] R3a2-3 LOGIN DOOR code done (door.rs, AD1b, desk-appdb.sh); waits his 3 server steps; then R3a2 DBSC, R4-1.. founder phases copied (Desk gate + /desk/v1 endpoints only).
> [21 Nov 2026 11:01 PKT] AFTER LOGIN: inside UI = founder phases COPIED in order (R4-1..R4-10, PLAN-DESK-UI-COPY-21NOV.md), Desk gate + /desk/v1 endpoints, never founder's. NEXT now: login door + AD1b.
> [21 Nov 2026 10:56 PKT] R3a2-2 owner CREATED + auth.rs installed (his runs). NEXT: login door + AD1b desk_app login > DBSC > orb > passkey > R3p > R3b-g. Aliases = company aliases, look first (desk-alias-look.sh).
> [21 Nov 2026 10:44 PKT] ORDER: R3a2-1 AD1 DONE (his paste 10:38) > R3a2-2 auth.rs ARGON2ID written, tests pass > his desk-install + desk-owner.sh > login door + AD1b > R3a2-3 DBSC > R3a1-b orb > R3a2-4 passkey > R3p plans > R3b-g. Real-account method: codes/REAL-ACCOUNT-METHOD.md
> [21 Nov 2026 10:35 PKT] R3a2: AD1 via scripts/ad-auto.sh (auto run or already run); NEXT auth.rs ARGON2ID
> [21 Nov 2026 10:31 PKT] NOW R3a2: AD1 SQL in his editor + server ad-check; NEXT auth.rs ARGON2ID (tech: Rust axum, argon2id, constant-time), DBSC, passkey. Compact-safe: state/COMPACT-SAVE.md
> **21 Nov 2026 10:45 PKT (his word 10:26: he runs SQL in the SQL EDITOR): `sql/AD1-editor.sql` built (header + AD1.sql + the 8-row CHECK last, because an editor shows only the last result); generated by scripts/make-editor-sql.py, the Desk gate fails if it is stale. Tested as a non-superuser twice (8/8 true). ISOLATION NOTE: in an editor the Desk schema `desk` lands in WHICHEVER database that editor is connected to (separate schema + separate role, but not a separate database); `ad-sql-run.sh` (own database anexo_desk) stays the stronger option.**

> **21 Nov 2026 10:35 PKT: his run of AD1.sql in a SQL EDITOR failed: `permission denied to alter role` (ALTER ROLE desk_app NOSUPERUSER NOBYPASSRLS needs a superuser). FIXED in AD1.sql: no ALTER ROLE, no extension, role created with defaults (the selftest fails the file if desk_app is ever superuser or bypasses RLS); the installing role gets one p_installer policy per table because FORCE RLS binds a non-superuser installer too. Tested as NON-superuser AND superuser: 8/8 checks, 2nd run ok, login lookup works, desk_app sees 0 owner rows directly. The right way to run it stays ad-sql-run.sh (own database anexo_desk on his server), NOT an editor.**

> **21 Nov 2026 10:20 PKT: his db list = anexo_copy, anexo_founder, postgres. DESK ISOLATION: the Desk gets its OWN database `anexo_desk` (created by ad-sql-run.sh, no other name). Runner tested end to end on a local PostgreSQL 16 with his broken PGHOST reproduced (creates the database, applies AD1, 8/8 checks true, second run skipped). The Desk now has its own WORKING-NOW.md inside this folder (state/WORKING-NOW.md, refreshed by ckpt.sh and the 2-minute loop) and state/PHASES.md (feature, code, technology, HAAN per phase).**

> **21 Nov 2026 10:05 PKT: his db-list paste failed (PGHOST has literal quotes in his root shell, fact only); ad-sql-run.sh fixed (own PSQL() with -h /var/run/postgresql, PG* cleared); NEXT his corrected read-only db list, then AD1 on his server.**

> **21 Nov 2026 10:40 PKT, HIS WORD 09:59 (in anger): the Admin Desk folder lives INSIDE the Claude docs folder: CANONICAL = docs/claude/admin-desk/ (edit only there); ONE IDENTICAL COPY stays at the repo root admin-desk/ ('main': the server installers and gates fetch it from origin/main). Sync: `python3 docs/cursor-work/server/desk-copy-sync.py sync`; the commit gate (rule DESK COPY) fails if the two differ.**

> **21 Nov 2026 10:30 PKT: R3a2 step 1 = AD1.sql WRITTEN + TESTED on PostgreSQL 16 (schema `desk`, role desk_app NOBYPASSRLS, 5 fadm_* tables with RLS ENABLED+FORCED, SHA-256 hash-chained append-only ledger, ARGON2ID-shaped hash check, audience `desk`, rp_id admindesk.anexomail.com, support@ banned, SECURITY DEFINER login lookup, selftest; 8/8 CHECK rows true). Runner admin-desk/scripts/ad-sql-run.sh (own ledger, no founder env). Gate row R3a2-sql = code. NOT run on his server yet (needs his database name). NEXT in order: auth.rs ARGON2ID + constant-time -> DBSC -> orb pulse/zoom -> passkey ceremony -> R3p.**

> **21 Nov 2026 10:15 PKT: R3a0-s2 HTTP/3 = PROVEN on his server (his paste 09:55): `anexomail-desk h3check` = H3CHECK OK, HTTP/3 200 on loopback AND 62.238.98.98 (client offered ONLY X25519MLKEM768 + AES-256-GCM). Gate row R3a0-stage2 = CODE, the HTTP/3 block is LIFTED. Page pill now says HTTP/3 QUIC . TLS 1.3 . AES-256-GCM . X25519MLKEM768 (needs his desk-install.sh once). STILL HIS HANDS: AAAA + HTTPS record (alpn=h3 port=4400). PHASE ORDER NOW: R3a2 = AD1 SQL -> auth.rs ARGON2ID -> DBSC -> orb pulse/zoom -> passkey ceremony -> R3p plans.**

> **21 Nov 2026 10:05 PKT (his word 09:52): ALL QUIC/UDP advanced technology written and gated: admin-desk/docs/QUIC-UDP-TECH-21NOV.md (QUIC, HTTP/3+QPACK, TLS1.3 AES-256-GCM only, X25519MLKEM768, Retry, migration, no 0-RTT, BBR, Alt-Svc, h3check = CODE; DATAGRAM/WebTransport, MoQ, QUIC v2, ECH = PLANNED with dates; DNS HTTPS record = his hands).**

> **21 Nov 2026 09:58 PKT: new Desk page LIVE (pill = TLS 1.3 . AES-256-GCM, no HTTP/2 word). HTTP/3 listener runs but the h3check proof did not run on his server (old binary behaviour + two pids): diagnosis line added to desk-h3-check.sh; the HTTP/3 words go on the page the moment H3CHECK OK is pasted; then AD1 ... in order.**

> **21 Nov 2026 09:55 PKT: Desk HTTP/3 IS LISTENING on his server (UDP 4400, journal line + ss). Proof tool `anexomail-desk h3check` + desk-h3-check.sh written; NEXT his desk-install.sh then desk-h3-check.sh (H3CHECK OK flips row R3a0-stage2 and opens AD1 ...), then his AAAA + HTTPS record port=4400 (browsers must reach the Desk's own port, not Caddy's 18443).**

> **21 Nov 2026 09:50 PKT (his anger 09:38): the Desk page may NEVER write HTTP/2 or HTTP/1 (pill shows only HTTP/3 QUIC when the browser reports h3, else just TLS 1.3 . AES-256-GCM; gate allowlist empty). desk-h3-enable.sh failed on cert Permission denied (rolled back, Desk up, h3 off); fixed with systemd LoadCredential; NEXT his re-run of desk-h3-enable.sh (one line) and desk-install.sh once for the new page.**

> **21 Nov 2026 09:45 PKT: desk-install.sh RAN OK on his server (h3 binary live, h3 still OFF); desk-h3-enable.sh ran first and rolled back by design. NEXT his ONE re-run of desk-h3-enable.sh, then AAAA + HTTPS record, curl --http3. AnexoChat UDP proven = 3443 (no clash with Desk UDP 4400).**

> **21 Nov 2026 09:40 PKT: Desk HTTP/3 port = UDP 4400 (from his fresh ss 09:27). h3.rs has a REAL loopback PQ test (X25519MLKEM768 + AES-256-GCM handshake + h3 request: PASS). Scripts desk-install.sh + desk-h3-enable.sh committed; the HTTP/3 block stays ON until his curl --http3 proof; then his AAAA + HTTPS record (port=4400).**

> **21 Nov 2026 09:30 PKT, HIS WORD 09:23: HTTP/1 AND HTTP/2 ARE BOTH BANNED (gate). Desk HTTP/3 listener CODE WRITTEN (admin-desk/server/src/h3.rs: quinn+h3, TLS 1.3 AES-256-GCM only, X25519MLKEM768 first, 5 tests pass); NOT live until his ss (UDP port) + AAAA/HTTPS record + curl --http3 proof. Order after that: AD1 SQL, auth.rs ARGON2ID, DBSC, orb pulse/zoom, passkey ceremony, R3p plans.**

> **21 Nov 2026 09:25 PKT, HIS WORD: HTTP/3 HARD BLOCK. HTTP/2 is BANNED for the Desk. No later phase (AD1 SQL, auth.rs ARGON2ID, DBSC, orb pulse/zoom, passkey ceremony, R3p plans) may exist in the repo until the Desk's own HTTP/3 + X25519MLKEM768 listener (R3a0-stage2) is in code and proven (his curl --http3). The gate fails the commit. Technology = founder's or more advanced.**

# ADMIN DESK BLUEPRINT (live copy of the Desk phases; his order 21 Nov 2026 08:19 PKT)
Updated: 21 Nov 2026 08:30 PKT. Plan with times: docs/claude/ADMIN-DESK-3DAY-PLAN-21NOV.md. The Desk is its OWN security domain (docs/claude/DESK-ISOLATION-GATE-21NOV.md). Rule 52: every browser call is signed and verified in the ONE Rust WASM kernel. SQL series for the Desk = AD1, AD2, ... (founder and awam keep the E series).
RULE (his word): in every phase, next to each FEATURE the CODE file and the ADVANCED TECHNOLOGY are written, and "HAAN" = yes only when the technology is really in that file AND seen working. The gate admin-desk/gates/DESK-FEATURES.json enforces this: missing technology = FAIL, NO COMMIT, shouted.

## PHASE R3a: Desk ka Ghar aur Darwaza (Sat 21 Nov 08:00 - 18:00)
### R3a0 HOST (admindesk.anexomail.com)
| Feature | Code | Technology | Haan |
|---|---|---|---|
| Own process on loopback 4400 | admin-desk/server/src/main.rs | RUST, TOKIO, AXUM 0.8 | YES (his install 08:19: listener 127.0.0.1:4400) |
| Wrong Host = 404 + journal line | admin-desk/server/src/main.rs (host_gate) | AXUM MIDDLEWARE | YES (his install: wrong host 404) |
| Security headers | admin-desk/server/src/main.rs (desk_headers) | CSP SELF-ONLY + TRUSTED TYPES, COOP, CORP, HSTS | YES in code + sandbox; public look pending |
| Own installer + unit + user | admin-desk/scripts/desk-install.sh | SYSTEMD HARDENING (NoNewPrivileges, ProtectSystem, MemoryDenyWriteExecute) | YES (his install ran) |
| Own bundle | founder-web/vite.desk.config.ts, desk.html | VITE 8 SEPARATE ENTRY | YES (build ok) |
| HTTP/3 + AES-256-GCM X25519MLKEM768 for this host | planned: SNI front + UDP 443 route | HTTP/3, QUIC, TLS 1.3 AES-256-GCM, X25519MLKEM768 | NO (stage 2, gate date 23 Nov) |
| AAAA + HTTPS alpn=h3 DNS | his Namecheap hands | DNS | NO |
### R3a1 CINEMATIC LOGIN
| Feature | Code | Technology | Haan |
|---|---|---|---|
| Night glass-walled office scene, gradient #060B19 / #0F3460 / amber rim | founder-web/src/desk/DeskScene.tsx | REACT 19, THREE.JS (LAZY DYNAMIC IMPORT, city-light points) | sandbox YES at 390/820/1280 (his design approved 08:31); his server NO until install |
| Mouse + phone-tilt parallax (wall, points and card move at different speeds; off with reduced motion) | DeskScene.tsx | POINTER EVENTS, DEVICEORIENTATION, requestAnimationFrame | code YES, live motion NOT yet seen by his eyes |
| Smoked liquid-glass card, 1px luminous edge, Desk identity only, ORIGINAL BrandMark logo + HoverA "A" kept | founder-web/src/desk/DeskSignIn.tsx | CSS BACKDROP-FILTER, original signin/BrandMark + BrandLoader | sandbox YES 390/820/1280 |
| Optional passkey button + honest hardware text (real PublicKeyCredential check) | DeskSignIn.tsx | WEBAUTHN detection; the passkey ceremony itself arrives with the Desk door R3a2 | detection YES; ceremony NO |
| Orb pulse, shockwave, zoom into 3-pane workspace | DeskScene.tsx (planned) | THREE.JS, GSAP | NO |
| Real telemetry: protocol (browser-reported), kernel state; Merkle only when the door reports a head; NO cipher line until stage 2 | founder-web/src/desk/DeskTelemetry.tsx | RUST WASM KERNEL (kernel.ts trust), PerformanceNavigationTiming | YES (values real; Merkle + cipher hidden on purpose) |
| Principle line + "Built on" technology line (only real technologies) | founder-web/src/desk/DeskSignIn.tsx, DeskPages.tsx | RUST, TOKIO, AXUM, WASM KERNEL, WEBAUTHN, THREE.JS (all in code) | YES in code (promise rows P5 proven, P6 open until R3f) |
### R3a2 LOGIN DOOR
| Feature | Code | Technology | Haan |
|---|---|---|---|
| Schema AD1: owner, sessions, ledger, desk_app | admin-desk/sql/AD1.sql (planned) | POSTGRESQL RLS, APPEND-ONLY SHA-256 HASH CHAIN | NO |
| /desk/v1/auth/login | admin-desk/server/src/auth.rs (planned) | ARGON2ID, CONSTANT-TIME, TOKEN AUDIENCE "desk" | NO |
| Device-bound session | auth.rs (planned) | DBSC | NO |
| Owner created by his command (password never in chat) | admin-desk/scripts (planned) | ARGON2ID | NO |

## DESK PRINCIPLE (his 21 Nov 2026 08:40, shown on the landing + login): "Our engine runs in milliseconds; our support should too. Own the issue, fix the root, leave zero open loops." It is a PROMISE (WEBSITE-PROMISES P6): R3f builds it (one owner per issue, SLA clock, an issue closes only with a root-cause note; no open loops).

## ONE ENGINE FOR ALL PLANS (his 21 Nov 08:53 question, answer YES): the awam plans Basic, Pro, Business, Business Pro, Business Premium, Business Max are DATA in the Desk (table fadm_plans in AD1: plan name, support lane, first-response hours, priority weight), not six builds. A company's plan reaches the Desk only through its own channel (Polar signed webhook / the Desk's own record), never by reading awam tables (isolation). The inbox, SLA clock and labels read the plan row. Open: which awam packages are live (his D answer) and the Business Max / Premium support terms.

## PLAN R3p (his 21 Nov 09:02): Premium + Max lanes first, founder technology only, no mix with awam: full plan with feature/code/technology/haan table = admin-desk/docs/PLAN-PREMIUM-MAX-21NOV.md (R3p0 terms from him, R3p1 AD2 SQL, R3p2 Polar webhook door, R3p3 lanes UI, R3p4 SLA clock, R3p5 named contact + quarterly review, R3p6 other four plans as rows).

## PHASES AFTER R3a (each gets its own feature table when it starts; plan times in the 3-day plan)
R3b inboxes (Sun 06:00) / R3c auto mail RFC 3834 + Polar signed webhook (12:00) / R3d dashboard + mail UI (17:00) / R3e reply without passkey (Mon 06:00) / R3f SLA engine (09:00) / R3g verify + final (14:00-21:00) / R4 Managed Move-In + Priority Support (from Tue 24 Nov) / R5 LEO / R6.

> [22 Nov 2026 01:13 PKT] PHASE R3-SCALE + WORLD-ADVANCE (his 01:12 target: world's most advanced): SCALE-50K-DESIGN-22NOV.md (S1..S11) + WORLD-ADVANCE-DESK-22NOV.md (W1..W10: transparent Merkle log, policy engine deny-by-default/forbid-wins, hybrid Ed25519+ML-DSA signing, MoQ-style WebTransport fan-out, zero standing privilege, data-view guard, per-staff keys). Each row needs his haan. Rule 52 on all. Not in code.

> [22 Nov 2026 01:14 PKT] PHASE R3-ONBOARD (ON1..ON8): EMPLOYEE-ACCOUNTS-PLAN-22NOV.md: enrollment token + device-bound passkeys + recovery + SCIM. Not in code; waits his haans.

> [22 Nov 2026 01:15 PKT] MASTER PLAN written: MASTER-PLAN-22NOV.md (points P1..P12 + 10-step build order with technology). CODE STARTS: step 1 R3d.

> [22 Nov 2026 01:25 PKT] ON1..ON12 FINAL (his answers: all haan; teams support / migration / frontend_demo; +4 zero-trust locks AAGUID, IP+shift, circuit breaker, no_access default). EMPLOYEE-ACCOUNTS-PLAN-22NOV.md. ORDER: R3d > dashboard+bridge > S1+S2 > ON1. Not in code.

> [22 Nov 2026 01:36 PKT] R3d stage B written + tested; waits his desk-install, then my live Chrome proof. NEXT: R4-1 shell/bridge on deskCall.

> [22 Nov 2026 01:47 PKT] STATUS-REAL-22NOV.md: LIVE vs CODE-ONLY vs PLAN-ONLY. Desk complete about 12 percent (1.5/12), whole plan about 3 percent live. R3d code pushed 01:38, his 01:39 paste shows the OLD script ran: rerun the pull command. TIME-STAMP FIX: ledger lines stamped 02:05-02:55 were wrong, real 01:3x-01:4x.

> [22 Nov 2026 01:55 PKT] R-CRM added to the Desk plan (his 01:54): CRM as much as the awam user gets, company style, built NEW. MASTER-PLAN-22NOV.md. Not in code.

- [22 Nov 2026 01:59 PKT] SANDBOX LIVE TEST done (real binary + real Postgres AD1/AD1b + real Chrome 390/820/1280): all pass after 2 UI fixes. SANDBOX-LIVE-TEST-22NOV.md. His rerun of desk-install is next, then my Chrome look on his real URL.
